package ar.edu.unlp.info.oo2.TrabajoPracticoRefactoring;

import java.util.SortedSet;

public interface Generador {
	
	public String obtenerNumero(SortedSet<String> lineas);
}
